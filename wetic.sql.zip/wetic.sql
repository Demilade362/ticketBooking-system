-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 01, 2023 at 11:55 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wetic`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminsystem`
--

CREATE TABLE `adminsystem` (
  `AdminID` int(11) NOT NULL,
  `AdminName` varchar(255) NOT NULL,
  `AdminPassword` varchar(255) NOT NULL,
  `Picture` text NOT NULL DEFAULT 'user-solid.svg',
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adminsystem`
--

INSERT INTO `adminsystem` (`AdminID`, `AdminName`, `AdminPassword`, `Picture`, `createdAt`) VALUES
(1, 'Admin1234', '$2y$10$xhm9vJM/TZnOJ3lJJxxT6O9GTeM9aP31OOuugpL0vN1yQC7zNKiK2', 'user-solid.svg', '2023-02-23 20:13:13');

-- --------------------------------------------------------

--
-- Table structure for table `loginsystem`
--

CREATE TABLE `loginsystem` (
  `usersId` int(11) NOT NULL,
  `usersName` varchar(128) NOT NULL,
  `picture` text DEFAULT 'user-solid.svg',
  `usersEmail` varchar(128) NOT NULL,
  `usersPwd` varchar(200) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `loginsystem`
--

INSERT INTO `loginsystem` (`usersId`, `usersName`, `picture`, `usersEmail`, `usersPwd`, `createdAt`) VALUES
(12, 'Demilade362', 'Demilade36263f7bb47155423.90224067.png', 'ademolademilade362@gmail.com', '$2y$10$xhm9vJM/TZnOJ3lJJxxT6O9GTeM9aP31OOuugpL0vN1yQC7zNKiK2', '2023-02-19 14:41:39'),
(16, 'Sunmisola100', 'Sunmisola10063f7bc0a765c85.31713976.jpg', 'sunmisola100@gmail.com', '$2y$10$9bcmAuPF43QC37.XPlmR5O6e7Me04yd8KsH75p7FAMrQkMnPc2h42', '2023-02-23 19:06:08');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `id` int(11) NOT NULL,
  `usersname` varchar(255) NOT NULL,
  `usersId` int(11) NOT NULL,
  `usersemail` varchar(255) NOT NULL,
  `localePlace` varchar(255) NOT NULL,
  `accountNo` varchar(200) NOT NULL,
  `ticketID` varchar(200) NOT NULL,
  `mode` varchar(200) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`id`, `usersname`, `usersId`, `usersemail`, `localePlace`, `accountNo`, `ticketID`, `mode`, `createdAt`) VALUES
(7, 'Demilade362', 12, 'ademolademilade362@gmail.com', 'Victoria-Island - N2000', '123456789001', '63f7b547850a63.33369166', 'Bus', '2023-02-23 18:49:43'),
(11, 'Demilade362', 12, 'ademolademilade362@gmail.com', 'Apapa - N4000', '123456789001', '63fb8d0da7e634.02727284', 'Train', '2023-02-26 16:47:09'),
(12, 'Sunmisola100', 16, 'sunmisola100@gmail.com', 'Lekki - N2000', '123456789001', '63fbb068ef9380.58403015', 'Aeroplane', '2023-02-26 19:18:00');

-- --------------------------------------------------------

--
-- Table structure for table `usedtickets`
--

CREATE TABLE `usedtickets` (
  `Id` int(11) NOT NULL,
  `usedTic` int(11) NOT NULL,
  `ticketID` varchar(255) NOT NULL,
  `usersName` varchar(255) NOT NULL,
  `mode` varchar(255) NOT NULL,
  `locale` varchar(255) NOT NULL,
  `UsedAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usedtickets`
--

INSERT INTO `usedtickets` (`Id`, `usedTic`, `ticketID`, `usersName`, `mode`, `locale`, `UsedAt`) VALUES
(18, 6, '63f7b526e84c53.13242117', 'Demilade362', 'Train', 'Lekki - N2000', '2023-02-25 00:52:49'),
(23, 10, '63fb8b41a7fcc5.12304339', 'Demilade362', 'Aeroplane', 'Lekki - N2000', '2023-02-26 17:17:31'),
(24, 10, '63fb8b41a7fcc5.12304339', 'Demilade362', 'Aeroplane', 'Lekki - N2000', '2023-02-26 17:17:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminsystem`
--
ALTER TABLE `adminsystem`
  ADD PRIMARY KEY (`AdminID`);

--
-- Indexes for table `loginsystem`
--
ALTER TABLE `loginsystem`
  ADD PRIMARY KEY (`usersId`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usersId` (`usersId`);

--
-- Indexes for table `usedtickets`
--
ALTER TABLE `usedtickets`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `usedTic` (`usedTic`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminsystem`
--
ALTER TABLE `adminsystem`
  MODIFY `AdminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `loginsystem`
--
ALTER TABLE `loginsystem`
  MODIFY `usersId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `usedtickets`
--
ALTER TABLE `usedtickets`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `tickets_ibfk_1` FOREIGN KEY (`usersId`) REFERENCES `loginsystem` (`usersId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
