<div class="footer bg-white pt-5 px-5 mt-5 d-none d-lg-block" style="padding-bottom: 7rem;">
    <p class="lead text-center">
        <span>Copyright &copy; <?php echo date('Y') ?> <span class="text-primary">We</span>Tic.</span>
    </p>
</div>